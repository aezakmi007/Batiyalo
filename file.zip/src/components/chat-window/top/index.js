import React from 'react';

function ChatTop() {
  return <div>Top</div>;
}

export default ChatTop;
