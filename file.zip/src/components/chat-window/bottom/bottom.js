import React from 'react';

function Chatbottom() {
  return <div>bottom</div>;
}

export default Chatbottom;
