import React from 'react';

function Messages() {
  return <div>Messages</div>;
}

export default Messages;
